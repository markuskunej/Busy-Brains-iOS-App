//
//  ViewController.swift
//  math game 2
//
//  Created by Noah Kunej on 2015-10-14.
//  Copyright © 2015 Markus Kunej. All rights reserved.
//

import UIKit
import AVFoundation
import Parse




class MathController: UIViewController {
    
    var timer = NSTimer()
    
    var incorrect: Int = 0
    
    var percent = 0.0
    
    @IBOutlet weak var box1: UIImageView!
    
    
    @IBOutlet weak var box2: UIImageView!
    
    
    @IBOutlet weak var box3: UIImageView!
    
    var xCounter = 0
    
    
    @IBOutlet var backButton: UIButton!
    var launchTimer = NSTimer()
    
    func runTimer() {
        seconds = 40
        
        timer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: Selector("subtractTime"), userInfo: nil, repeats: true)
        
        
        subtractTime()
        
    }
    
    func countdown() {
        seconds = 3
        
        launchTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: Selector("updateCountdownTimer"), userInfo: nil, repeats: true)    }
    
    @IBAction func BackToHome(sender: AnyObject) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("WelcomeView") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)
        
    
  

        
        
    }
    
    func updateCountdownTimer() {
        if (seconds == 1) {
            launchTimer.invalidate()
            randomrun()
            runTimer()
            score = 0
            scoreText.text = "Score:"
            startText.hidden = true
            round = 1
            print (array)
        } else {
            seconds--
            launchtimerLabel.text = "\(seconds)"
        }
    }
    
    
    
    
    func subtractTime() {
        if (seconds == -1) {
        timer.invalidate()
            endgame()
        
        }
        
        else if(seconds == 0)  {
            timer.invalidate()
            endgame()
            
            
        } else {
            seconds--
            timerLabel.text = "Time: \(seconds)"
        }
    }
    
    
    
    
    
    
    @IBOutlet weak var launchtimerLabel: UILabel!
    
    @IBOutlet var roundLabel: UILabel!
    
    
    @IBOutlet var timerLabel: UILabel!
    
    @IBOutlet weak var Line: UILabel!

    @IBOutlet weak var firstText: UILabel!
    
    @IBOutlet weak var signText: UILabel!
    
    @IBOutlet weak var secondText: UILabel!
    
    @IBOutlet weak var resultText: UILabel!
    
    @IBOutlet weak var scoreText: UILabel!
    
    @IBOutlet weak var startText: UILabel!
    
    @IBOutlet weak var dataText: UILabel!
    
    @IBOutlet weak var correctText: UIButton!
    
    @IBOutlet weak var wrongText: UIButton!
    
    @IBOutlet weak var rules: UITextView!
    
    @IBOutlet weak var scoreButton: UIButton!
    
    var seconds = 3
    
    var count = 0
    
    var now = NSDate()
    

    
    let formatter = NSDateFormatter()
    
    var dateCheck = String()
    
    var simpleDate = String()
    
    var data = String()
    
    var firstNumber = Int()
    
    var secondNumber = Int()
    
    var random1 = Int()
    
    var answer = Int()
    
    let lowerValue = -9
    
    let upperValue = 9
    
    var result = Int()
    
    var wrongAnswer = Int()
    
    var random2 = Int()
    
    var score: Int = 0
    
    var round = 1
    
    var oppositeAnswer = Int()
    
    var array = [String]()
    
    
    
    
    
    
    
    
    
    
    func reset() {
        secondText.hidden = true
        signText.hidden = true
        firstText.hidden = true
        startText.hidden = false
        correctText.hidden = true
        wrongText.hidden = true
        scoreText.hidden = true
        rules.hidden = false
        resultText.hidden = true
        timerLabel.hidden = true
        scoreButton.hidden = false
        Line.hidden = true
        launchtimerLabel.hidden = true
        backButton.hidden = false
        score = 0
        box1.hidden = true
        box2.hidden = true
        box3.hidden = true
        
    }
    
    func hidestuff() {
        startText.hidden = true
        rules.hidden = true
        scoreButton.hidden = true
        launchtimerLabel.hidden = false
        backButton.hidden = true
    }
    
    

    

    
    func showStuff(){
        secondText.hidden = false
        signText.hidden = false
        firstText.hidden = false
        startText.hidden = true
        correctText.hidden = false
        wrongText.hidden = false
        scoreText.hidden = false
        rules.hidden = true
        resultText.hidden = false
        scoreButton.hidden = true
        backButton.hidden = true
        
        timerLabel.hidden = false
        roundLabel.hidden = false
        Line.hidden = false
        launchtimerLabel.hidden = true
        
    }
    
    
    
    
    func randomrun() {
        
        
        showStuff()
        roundLabel.text = "Round: \(round)"
        
        
        firstNumber = Int(arc4random_uniform(201))
        
        secondNumber = Int(arc4random_uniform(UInt32(firstNumber)))
        
        random1 = Int(arc4random_uniform(2))
        
        if random1 == 1 {
            answer = firstNumber + secondNumber
        } else {
            answer = firstNumber - secondNumber
        }
        
        if random1 == 1 {
            oppositeAnswer = firstNumber - secondNumber
        } else {
            oppositeAnswer = firstNumber + secondNumber
        }
        
        result = Int(arc4random_uniform(UInt32(upperValue - lowerValue + 1))) +   lowerValue
        
        wrongAnswer = answer + result
        
        if wrongAnswer == answer {
            wrongAnswer = wrongAnswer + 1
        }
        random2 = Int(arc4random_uniform(6))
        
      
        
            firstText.text = "\(firstNumber)"
            secondText.text = "\(secondNumber)"
            if random1 == 1 {
                signText.text = "+"
            } else {
                signText.text = "-"
            }
            if random2 <= 2 {
                resultText.text = "\(answer)"
            } else if random2 == 3 {
                resultText.text = "\(wrongAnswer)"
            } else if random2 == 4 {
                resultText.text = "\(answer + 10)"
            } else if random2 == 5 {
                resultText.text = "\(oppositeAnswer)"
        }
        
        
        if xCounter == 3 {
            endgame()
        }
    }
    
    
    
    
    
    
    @IBAction func startButton(sender: AnyObject) {
        
        
        if pass == true {
            hidestuff()
            countdown()
        
        } else {
        if simpleDate != dateCheck {
        hidestuff()
        countdown()
        } else {
        rules.text = "Sorry, you have reached your limit!"
        } }
    }
    
    
    @IBAction func Correct(sender: AnyObject) {
        if random2 <= 2 {
            score = score + 1
        } else {
            xCounter = xCounter + 1
            playSound()
            imageShow()
        }
        
         incorrect = incorrect + 1
        scoreText.text = "Score: \(score)"
        
        round = round + 1
        
     if xCounter == 3 {
            endgame()
        } else {
        randomrun()
        }
    }
    
    @IBAction func Wrong(sender: AnyObject) {
        if random2 >= 3 {
            score = score + 1
        } else {
            xCounter = xCounter + 1
            playSound()
            imageShow()
        }
        incorrect = incorrect + 1
        
    scoreText.text = "Score: \(score)"
        
        round = round + 1
        
        if xCounter == 3 {
            endgame()
        } else {
        randomrun()
        }
    
    }
    
    func endgame() {
        timer.invalidate()
        seconds = -1
        
        
        
            formatter.dateStyle = .MediumStyle
            
            simpleDate = formatter.stringFromDate(now)
            
            data = "\(simpleDate): \(score)"
            
            startText.hidden = false
        
            roundLabel.hidden = true
        
        
        
        
            array.append(data)
            
            let mathData = NSUserDefaults.standardUserDefaults()
    
            mathData.setObject(array, forKey: "MathScores")
        
            mathData.setObject(simpleDate, forKey: "DateCheck")
        
        
        
        
        percent = Double((score/round)*100)
        
        
        
        //let savescore = score
        
        
    
        //Usersquery.whereKey("objectId", matchesRegex: objectId)
        
        //Usersquery.getObjectInBackgroundWithId(objectId) {
          //  (user1: PFObject?, error: NSError?) -> Void in
            //if error != nil {
              //  print(error)
            //} else if let user1 = user1 {
              //  user1["MathGame"] = savescore
                //user1.saveInBackground()
               // user1.saveEventually()
                
                
            //}
       // }
        
        
        
        
        
        

        
        today.setValue(percent, forKey: "MathGamePercentage")
        user1.setValue(percent, forKey: "MathGamePercentage")
        user.setValue(percent, forKey: "MathGamePercentage")
      
        
        homeRoomScores.setValue(score, forKey: "MathGame")
        gradeScores.setValue(score, forKey: "MathGame")
        
        
        today.setValue(score, forKey: "MathGame")
        user1.setValue(score, forKey: "MathGame")
        user.setValue(score, forKey: "MathGame")
        
        today.saveEventually()
        user1.saveEventually()
        user.saveEventually()
        homeRoomScores.saveEventually()
        gradeScores.saveEventually()
    
        
            reset()
        
    }
    
    var audioPlayer: AVAudioPlayer!
    
    func playSound() {
        do {
           self.audioPlayer = try AVAudioPlayer(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("buzzer", ofType: "mp3")!))
            self.audioPlayer.play()
        } catch {
            print("Error")
        }
    }
    
    func imageShow() {
        if xCounter == 1 {
            box1.hidden = false
        }
        if xCounter == 2 {
            box2.hidden = false
        }
        if xCounter == 3 {
            box3.hidden = false
            
        }
    }
    

override func viewDidLoad() {
    super.viewDidLoad()
    reset()
    let mathData = NSUserDefaults.standardUserDefaults()
    if mathData.objectForKey("MathScores") != nil {
    array = mathData.objectForKey("MathScores") as? [String] ?? [String]()
    }
    if mathData.stringForKey("DateCheck") != nil {
    simpleDate = mathData.stringForKey("DateCheck")as String!
    }
    
    
    formatter.dateStyle = .MediumStyle
    
    dateCheck = formatter.stringFromDate(now)
    }
    


override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}

}













