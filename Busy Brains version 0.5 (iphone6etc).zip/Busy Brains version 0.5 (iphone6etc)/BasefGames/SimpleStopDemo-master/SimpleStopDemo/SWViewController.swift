//
//  AppDelegate.swift
//  SimpleStop
//
//  Created by Nakul on 5/06/15.
//  Copyright (c) 2015 BasefProject. All rights reserved.
//

import UIKit

import Darwin

var elapsedTime :float_t = 0.0
var reactiontime : float_t = 0.0
var controller = UIViewController.self


class SWViewController: UIViewController {
    
    
    @IBAction func BackToHome(sender: AnyObject) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("WelcomeView") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @IBOutlet weak var textBox: UILabel!
    
    
    
    var dateCheck = String()
    
    let formatter = NSDateFormatter()
    
    var simpleDate = String()
    
    var now = NSDate()
    
    @IBAction func Start(sender: AnyObject) {
        if pass == true {
            let controller = storyboard!.instantiateViewControllerWithIdentifier("timeGame") as UIViewController
            
            self.presentViewController(controller, animated: true, completion: nil)
            
        } else {
        
            if simpleDate != dateCheck{
                let controller = storyboard!.instantiateViewControllerWithIdentifier("timeGame") as UIViewController
                
                self.presentViewController(controller, animated: true, completion: nil)        } else {
                textBox.text = "Sorry, you can only play once per day!"
            }
        }}

    
   
    

    
    override func viewDidLoad() {
        let defaults = NSUserDefaults.standardUserDefaults()
        if defaults.stringForKey("DateCheck3") != nil {
            simpleDate = defaults.stringForKey("DateCheck3") as String!
        }
        
        formatter.dateStyle = .MediumStyle
        
        dateCheck = formatter.stringFromDate(now)
        super.viewDidLoad()
        
       
}


    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
