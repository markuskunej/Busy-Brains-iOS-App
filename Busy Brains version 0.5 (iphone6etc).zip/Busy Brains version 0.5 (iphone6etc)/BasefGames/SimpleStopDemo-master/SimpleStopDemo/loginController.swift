//
//  loginController.swift
//  MultipleStoryboards
//
//  Created by Noah Kunej on 2016-01-03.
//  Copyright © 2016 myOrg. All rights reserved.
//

import Parse
import UIKit

let Usersquery = PFQuery(className:"Users")


let Homeroomquery = PFQuery(className:homeroom)


let Gradequery = PFQuery(className: grade)


let Individualquery = PFQuery(className: name)



class loginController: UIViewController {

    @IBOutlet weak var nameInput: UITextField!
    
    @IBOutlet weak var emailInput: UITextField!
    
    @IBOutlet var homeRoomInput: UITextField!
    
    @IBOutlet var Grade: UITextField!
    
    var username = String()
    
    
    
    
    
    
    @IBAction func begin(sender: AnyObject) {
        
        
        if nameInput.text != "" {
            
            username = nameInput.text!
            
            
            name = nameInput.text!
            homeroom = homeRoomInput.text!
            email = emailInput.text!
            grade = Grade.text!
            
            
            
        }
        

        
        
        
            func saveName() {
                
                let defaults = NSUserDefaults.standardUserDefaults()
                
                
                
                defaults.setObject(name, forKey: "Name")
                
                defaults.setObject(homeroom, forKey: "Homeroom")
                
                defaults.setObject(email, forKey: "Email")
                
                defaults.setObject(grade, forKey: "Grade")
                
                }
            
        
 saveName()
            
            
            
            
            
            
            
            
            
            
        if nameInput.text == "nakul" {
            pass = true
            
            
            
            user1["name"] = nameInput.text!
            user.username = "my name"
            user.password = "my pass"
            user.email = "email@example.com"
            name = nameInput.text!
            user.signUpInBackground()
            user1.saveInBackgroundWithBlock({ (success: Bool, error: NSError?) -> Void in
                print("Object has been saved.")
            })
        }
            
            
            
            
            
            
        grade = Grade.text!
        homeroom = homeRoomInput.text!
        homeRoomScores["name"] = nameInput.text!
        user.setValue(grade, forKeyPath: "Grade")
        user.setValue(homeroom, forKeyPath: "Homeroom")
        gradeScores["name"] = nameInput.text!
        user1["name"] = nameInput.text!
        user.username = nameInput.text!
        user.email = emailInput.text!
        user.password = "my pass"
        name = nameInput.text!
        user.signUpInBackground()
        user1.saveEventually()
        homeRoomScores.saveEventually()
        gradeScores.saveEventually()
        
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewControllerWithIdentifier("WelcomeView") as UIViewController
            self.presentViewController(controller, animated: true, completion: nil)
        
                
    
                saveName()
        
            
        }

        
        
        
        
    

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = NSUserDefaults.standardUserDefaults()
        
        if defaults.stringForKey("Name") != nil {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewControllerWithIdentifier("WelcomeView") as UIViewController
        self.presentViewController(controller, animated: true, completion: nil)
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
