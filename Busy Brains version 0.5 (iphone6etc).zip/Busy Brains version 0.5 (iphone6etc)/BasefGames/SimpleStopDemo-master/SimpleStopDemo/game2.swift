//
//  game2.swift
//  SimpleStopDemo
//
//  Created by Nakul Malhotra on 6/15/15.
//  Copyright (c) 2015 Nakul Malhotra. All rights reserved.
//

import UIKit

import Darwin

class game2: UIViewController {
    
    //if usertouchesscreen (make button) then tell them to restart, if not continue with app
    
    @IBOutlet weak var stop: UIButton!
        
    @IBOutlet var start: UIButton!

    @IBOutlet var restart: UIButton!
    
    @IBAction func Restart(sender: AnyObject)
    {delayTime = DISPATCH_TIME_FOREVER
        timer.invalidate()
        reaction.hidden = false
        sleep(1)
        reset()

    }
    var reactionTime2 = 0.0
    
    var totalTime = 0.0
    
    var averageTime = 0.0
    
    var level = 1
    
    var data = String()
    
    var now = NSDate()
    
    var formatter = NSDateFormatter()
    
    var dateCheck = String()
    
    var simpleDate = String()
    
    var timeArr = [String]()
    
    var newButtonX: CGFloat?
    
    var newButtonY: CGFloat?
    
    var startTime = NSTimeInterval()
    
    var timer:NSTimer = NSTimer()
    
    @IBOutlet var reaction: UILabel!
    
    @IBOutlet var displayTimeLabel: UILabel!
    
    var seconds = 4.0
    //var delay = //seconds * Double(NSEC_PER_SEC)  // nanoseconds per seconds
    
    
    
    
    func blue(){
        self.view.backgroundColor = UIColor(red: (150/255.0), green: (239/255.0), blue: (210/255.0), alpha: 1.0); }
    
    func red(){
        self.view.backgroundColor = UIColor(red: (206/255.0), green: (38/255.0), blue: (54/255.0), alpha: 1.0);
        }

    
    func green(){
        self.view.backgroundColor = UIColor(red: (75/255.0), green: (219/255.0), blue: (106/255.0), alpha: 1.0);
    }
        
    
    func reset() {
            stop.hidden = true
            reaction.hidden = true
            restart.hidden = true
            blue()
            start.hidden = false
    }
    
    
    
    

    
    var counter = 1
    var delayTime: dispatch_time_t = 0
        
    
    @IBAction func start(sender: AnyObject) {
        if counter == 0 {
        counter = 1
        }
        
        red()
        start.hidden = true
        restart.hidden = false
        

        if counter == 1 {
        let truerandom = Double(arc4random_uniform(10))

            
        delayTime = dispatch_time(DISPATCH_TIME_NOW,Int64(truerandom * Double(NSEC_PER_SEC)))
                                
            
        dispatch_after(delayTime, dispatch_get_main_queue()) {
            
                    self.green()
            
                    self.restart.hidden = true
            
                    self.stop.hidden = false
            

                
                    let aSelector : Selector = "updateTime"
                    self.timer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: aSelector, userInfo: nil, repeats: true)
                    self.startTime = NSDate.timeIntervalSinceReferenceDate()
                
                // Find the button's width and height
                //let buttonWidth = stop.frame.width
                //let buttonHeight = stop.frame.height
                
                // Find the width and height of the enclosing view
                //let viewWidth = stop.superview!.bounds.width
                //let viewHeight = stop.superview!.bounds.height
                
                // Compute width and height of the area to contain the button's center
                //let xwidth = viewWidth - buttonWidth
                //let yheight = viewHeight - buttonHeight
                
                // Generate a random x and y offset
                //let xoffset = CGFloat(arc4random_uniform(UInt32(xwidth)))
                //let yoffset = CGFloat(arc4random_uniform(UInt32(yheight)))
                
                //newButtonX = xoffset + (buttonWidth / 2)
                //newButtonY = yoffset + (buttonHeight / 2)
                
                //stop.center.x = newButtonX!
                //stop.center.y = newButtonY!
            }
            }
        }
        
    
    
    
        func updateTime() {
            
            let currentTime = NSDate.timeIntervalSinceReferenceDate()
            let elapsedTime: NSTimeInterval = currentTime - startTime
           
            showingtime()
            
            reaction.hidden = false
            
            var reactiontime = round(1000 * elapsedTime)
            reactiontime = round(reactiontime)
            reactionTime2 = reactiontime
            let c:String = String(reactiontime)
            reaction.text = ("MS:") + c
        }
    
    
    
        
        func showingtime() {
            let currentTime = NSDate.timeIntervalSinceReferenceDate()
            //Find the difference between current time and start time.
            var elapsedTime: NSTimeInterval = currentTime - startTime
            
            //calculate the minutes in elapsed time.
            let minutes = UInt8(elapsedTime / 60.0)
            elapsedTime -= (NSTimeInterval(minutes) * 60)
            
            //calculate the seconds in elapsed time.
            let seconds = UInt8(elapsedTime)
            elapsedTime -= NSTimeInterval(seconds)
            
            //find out the fraction of milliseconds to be displayed.
            _ = UInt8(elapsedTime * 100)
            
            
            //add the leading zero for minutes, seconds and millseconds and store them as string constants
            //let strMinutes = minutes > 9 ? String(minutes):"0" + String(minutes)
            //let strSeconds = seconds > 9 ? String(seconds):"0" + String(seconds)
            //let strFraction = fraction > 9 ? String(fraction):"0" + String(fraction)
            
            //concatenate minuets, seconds and milliseconds as assign it to the UILabel
            //displayTimeLabel.text = "\(strMinutes):\(strSeconds):\(strFraction)"
        }
    func endgame(){
        level = level + 1
        if level == 6 {
            formatter.dateStyle = .MediumStyle
            
            simpleDate = formatter.stringFromDate(now)
            
            averageTime = totalTime / 5
            
            data = "\(simpleDate): \(averageTime)"
            
            start.hidden = false
            
            
            
            timeArr.append(data)
            
            let defaults = NSUserDefaults.standardUserDefaults()
            
            defaults.setObject(timeArr, forKey: "TimeScores")
            
            defaults.setObject(simpleDate, forKey: "DateCheck3")
        
            homeRoomScores.setValue(averageTime, forKey: "ReactionTime")
            gradeScores.setValue(averageTime, forKey: "ReactionTime")
            today.setValue(averageTime, forKey: "ReactionTime")
            user1.setValue(averageTime, forKey: "ReactionTime")
            user.setValue(averageTime, forKey: "ReactionTime")
            
            
            user1.saveEventually()
            user.saveEventually()
            today.saveEventually()
            homeRoomScores.saveEventually()
            gradeScores.saveEventually()
            
            averageTime = 0            
            
            let storyboard = UIStoryboard(name: "memory", bundle: nil)
            let controller = storyboard.instantiateViewControllerWithIdentifier("MemoryController") as UIViewController
            
            self.presentViewController(controller, animated: true, completion: nil)
        

        
        }
    }
    
    
        
        

        
        
    
        
    @IBAction func stop(sender: AnyObject) {
        timer.invalidate()
        totalTime = totalTime + reactionTime2
        reaction.hidden = false
        sleep(1)
        reset()
        endgame()
        
    }
    
    
        
        
        override func viewDidLoad() {
            let defaults = NSUserDefaults.standardUserDefaults()
            if defaults.objectForKey("TimeScores") != nil {
                timeArr = defaults.objectForKey("TimeScores") as? [String] ?? [String]()
            }
            if defaults.stringForKey("DateCheck3") != nil {
                simpleDate = defaults.stringForKey("DateCheck3") as String!
            }
            
            formatter.dateStyle = .MediumStyle
            
            dateCheck = formatter.stringFromDate(now)
            super.viewDidLoad()
        reset()
        }
        
        
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
    }



