//
//  memory.swift
//  SimpleStopDemo
//
//  Created by Nakul Malhotra on 8/10/15.
//  Copyright © 2015 Nakul Malhotra. All rights reserved.
//

import UIKit

class memory: UIViewController {
    
    var Image: [UIImage] = [
        UIImage(named: "purple.png")!,
        UIImage(named: "red.png")!,
        UIImage(named: "blue.png")!,
        UIImage(named: "green.png")!,
        UIImage(named: "light.png")!
        
    ]
    
    
   
    @IBOutlet var nowpicture: UIImageView!
    var previouspicture: UIImageView!
    

    
    @IBAction func start(sender: AnyObject) {
        
        yes.hidden = false
        no.hidden = false
        starter.hidden = true
        let randomIndex = Int(arc4random_uniform(UInt32(Image.count)))
        nowpicture.image = (Image[randomIndex])
        
        
        
    }
    
    
    
    
    
    @IBOutlet var starter: UIButton!
    
    @IBOutlet var yes: UIButton!
    
    @IBOutlet var no: UIButton!
    
    @IBAction func yes(sender: AnyObject) {
        var oldpicture:UIImage = nowpicture.image!
        let randomIndex = Int(arc4random_uniform(UInt32(Image.count)))
        nowpicture.image = (Image[randomIndex])
        
      
        
}
   
 
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
