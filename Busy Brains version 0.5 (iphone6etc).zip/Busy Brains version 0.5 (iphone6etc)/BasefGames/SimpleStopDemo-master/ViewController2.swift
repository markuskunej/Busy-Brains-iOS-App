//
//  ViewController2.swift
//  SimpleStopDemo
//
//  Created by Noah Kunej on 2015-11-15.
//  Copyright © 2015 Ravi Shankar. All rights reserved.
//

import UIKit

class ViewController2: UIViewController, UITableViewDataSource {
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return timeArr.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        
        
        let(scores) = timeArr [indexPath.row]
        
        
        
        
        cell.textLabel!.text = scores
        return cell
    }
    
    var timeArr = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = NSUserDefaults.standardUserDefaults()
        
        timeArr = defaults.objectForKey("TimeScores") as? [String] ?? [String]()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
