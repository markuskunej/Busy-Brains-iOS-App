//
//  ViewController.swift
//  decisionmaking
//
//  Created by Nakul Malhotra on 10/2/15.
//  Copyright © 2015 basefproject. All rights reserved.
//

import UIKit
import CoreData
import AVFoundation
var pass: Bool?

class DecisionController: UIViewController {
    var seconds = 3
    
    var percent = 0.0
    
    
    var count = 0

    @IBOutlet var timerLabel: UILabel!
    var timer = NSTimer()
    
    func runTimer() {
        seconds = 30
        
        timer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: Selector("subtractTime"), userInfo: nil, repeats: true)
        
        
        subtractTime()
        
    }
    
    func subtractTime() {
        if (seconds == -1) {
            round = 20
            xCounter = 3
            endgame()
            timer.invalidate()
            
        }
            
        else if(seconds == 0)  {
            round = 20
            xCounter = 3
            endgame()
            timer.invalidate()
            
            
        } else {
            seconds--
            timerLabel.text = "Time: \(seconds)"
        }
    }
    
    var audioPlayer: AVAudioPlayer!
    
    func playSound() {
        do {
            self.audioPlayer = try AVAudioPlayer(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("buzzer", ofType: "mp3")!))
            self.audioPlayer.play()
        } catch {
            print("Error")
        }
    }
    
    func imageShow() {
        if xCounter == 1 {
            box1.hidden = false
        }
        if xCounter == 2 {
            box2.hidden = false
        }
        if xCounter == 3 {
            box3.hidden = false
            
        }
    }
    
    
    
    
    
    @IBAction func BackToHome(sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("WelcomeView") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)
    }

    
    var rpsimages: [UIImage!] = [
        UIImage(named: "rock.png"),
        UIImage(named: "paper.png"),
        UIImage(named: "scissors.png"),
    ]
    
    var squareimages: [UIImage!] = [
        UIImage(named: "black square.png"),
        UIImage(named: "dark blue square.png"),
        UIImage(named: "green square.png"),
        UIImage(named: "grey square"),
        UIImage(named: "red square")
    ]

    var points = 0
    
    var winnerchoice: Int = 0
    
   
    //note the points are more than the winnerchoice, this cannot be influnced by the winnerchoice
    
    
    
    @IBOutlet var choice1: UIButton!
    
    @IBOutlet var choice2: UIButton!
    
    
    @IBOutlet var comp: UILabel!
    
    @IBOutlet var image1: UIImageView!
    
    @IBOutlet var image2: UIImageView!
    
    @IBOutlet var start: UIButton!
    
    @IBOutlet var choiceduno: UILabel!
    
    @IBOutlet var equal: UIButton!
    
    @IBOutlet weak var score: UIButton!
    
    
    @IBOutlet weak var box1: UIImageView!
    
    @IBOutlet weak var box2: UIImageView!
    
    @IBOutlet weak var box3: UIImageView!
    
    @IBOutlet weak var scoreText: UILabel!
    
    
    
    
    var xCounter = 0
    
    var winner: Int = 0
    
    var round = 1
    
    var now = NSDate()
    
    let formatter = NSDateFormatter()
    
    var dateCheck = String()
    
    var simpleDate = String()
    
    var data = String()
    
    var decisionArr = [String]()

    
    var rpschoice1ofpc: Int = 0
    var rpschoice2ofpc: Int = 0
    var imagesonscreen = (0, 0)
    
    
    var squarechoice1ofpc: Int = 0
    var squarechoice2ofpc: Int = 0
  
    
    @IBOutlet var backButton: UIButton!
    
    @IBAction func Start(sender: AnyObject) {
        if pass == true {
            randomrun()
            equal.hidden = false
            start.hidden = true
            score.hidden = true
            timerLabel.hidden = false
            backButton.hidden = true
            choice1.hidden = false
            choice2.hidden = false
            scoreText.hidden = false
            
            
           
            runTimer()
            
        
        } else {
        if simpleDate != dateCheck {
        randomrun()
            equal.hidden = false
            start.hidden = true
            score.hidden = true
            timerLabel.hidden = false
            backButton.hidden = true
            choice1.hidden = false
            choice2.hidden = false
            scoreText.hidden = false
        equal.hidden = false
        start.hidden = true
        score.hidden = true
              backButton.hidden = true
        runTimer()
            choice1.hidden = false
        timerLabel.hidden = false
            backButton.hidden = true
            
        } else {
            timerLabel.text = "Sorry, you can have reached your playing limit!"
            
            }
        
        }
        
        
    }

    func pointexecuter () {
        if winnerchoice == winner {
            points = points + 1
            scoreText.text = "Score: \(points)"
  
        } else {
            points = points + 0
            xCounter = xCounter + 1
            playSound()
            imageShow()
        }                   }
    
    @IBAction func arraytrigger(sender: AnyObject) {
        choiceofarray()
    }
   
    var arraychoice: Int = Int(0)

    @IBOutlet var decisionchoice: UILabel!
    func choiceofarray () {
        decisionchoice.text = "rpsimages"
    }
    
    
    
    func winnercheck () {
        if decisionchoice.text == "rpsimages" {
        
        switch imagesonscreen{
            
        case (1,2): winner = 1
        case (2,1): winner = 1
        case (1,3): winner = 3
        case (3,1): winner = 3
        case (2,3): winner = 2
        case (3,2): winner = 2
        case (3,3): winner = 0
        case (2,2): winner = 0
        case (1,1): winner = 0
            
        default: winner = 0
        }
            
            } else if decisionchoice.text == "squareimages" {
            switch imagesonscreen{
            case (5,4): winner = 5
            case (5,3): winner = 5
            case (5,2): winner = 5
            case (5,1): winner = 5
            case (4,5): winner = 5
            case (4,3): winner = 4
            case (4,2): winner = 4
            case (4,1): winner = 4
            case (3,5): winner = 5
            case (3,4): winner = 4
            case (3,2): winner = 3
            case (3,1): winner = 3
            case (2,5): winner = 5
            case (2,4): winner = 4
            case (2,3): winner = 3
            case (2,1): winner = 2
            case (1,5): winner = 5
            case (1,4): winner = 4
            case (1,3): winner = 3
            case (1,2): winner = 2
            case (1,1): winner = 0
            case (2,2): winner = 0
            case (3,3): winner = 0
            case (4,4): winner = 0
            case (5,5): winner = 0
                
            default: winner = 0
            }
                }
                    }
    
    
    
    @IBAction func Equal(sender: AnyObject) {
        winnerchoice = 0
        onscreencheck()
        winnercheck()
        pointexecuter()
        randomrun()
        endgame()
    }
    
    
    
    func randomimage1 ()   {
        
        if decisionchoice.text == "rpsimages" {
        let randomIndex = Int(arc4random_uniform(UInt32(rpsimages.count)))
        image1.image = (rpsimages[randomIndex])
        
        
        } else {
            let randomIndex = Int(arc4random_uniform(UInt32(squareimages.count)))
            image1.image = (squareimages[randomIndex])
        }
        
        
    }
    
    
    
    func randomimage2 ()  {
        
        if decisionchoice.text == "rpsimages" {
            let randomIndex = Int(arc4random_uniform(UInt32(rpsimages.count)))
            image2.image = (rpsimages[randomIndex])
       
        
        } else if decisionchoice.text == "squareimages" {
            let randomIndex = Int(arc4random_uniform(UInt32(squareimages.count)))
            image2.image = (squareimages[randomIndex])
        }
        
    }
    
    func endgame(){
        if xCounter == 3 {
            timerLabel.hidden = true
            formatter.dateStyle = .MediumStyle
            
            simpleDate = formatter.stringFromDate(now)
            
            data = "\(simpleDate): \(points)"
            
            start.hidden = false
            
            equal.hidden = true
            
            backButton.hidden = false
            
            
            score.hidden = false
            
            choice1.hidden = true
            choice2.hidden = true
            
            image1.hidden = true
            image2.hidden = true
            
            box1.hidden = true
            box2.hidden = true
            box3.hidden = true
            
            scoreText.hidden = true
            
            decisionArr.append(data)
            
           
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            let defaults = NSUserDefaults.standardUserDefaults()
            
            defaults.setObject(decisionArr, forKey: "DecisionScores")
            
            defaults.setObject(simpleDate, forKey: "DateCheck2")
           
            
            
            
            today.setValue(percent, forKey: "DecisionMakingPercentage")
            user1.setValue(percent, forKey: "DecisionMakingPercentage")
            user.setValue(percent, forKey: "DecisionMakingPercentage")
            
            
            
            
            
            
            
            
            
            
            homeRoomScores.setValue(points, forKey: "DecisionMaking")
            gradeScores.setValue(points, forKey: "DecisionMaking")
            today.setValue(points, forKey: "DecisionMaking")
            user1.setValue(points, forKey: "DecisionMaking")
            user.setValue(points, forKey: "DecisionMaking")
            
            user1.saveEventually()
            user.saveEventually()
            today.saveEventually()
            homeRoomScores.saveEventually()
            gradeScores.saveEventually()
            
          
 
        }
    }
    
    
 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func choice1(sender: AnyObject) {
        imageone()
        onscreencheck()
        winnercheck()
        pointexecuter()
        randomrun()
        endgame()
        
    }
    
    
    @IBAction func choice2(sender: AnyObject) {
        imagetwo()
        onscreencheck()
        winnercheck()
        pointexecuter()
        randomrun()
        endgame()
    }
    
    
    
    
    func randomrun () {
        randomimage1()
        randomimage2()

        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    func squareonscreencheck () {
        if image1.image == UIImage(named: "black square.png")  {
            squarechoice1ofpc = 5
        } else if image1.image == UIImage(named: "grey square.png") {
            squarechoice1ofpc = 4
        } else if image1.image == UIImage(named: "red square.png"){
            squarechoice1ofpc = 3
        } else if image1.image == UIImage(named: "green square.png"){
            squarechoice1ofpc = 2
        } else if image1.image == UIImage(named: "dark blue square.png") {
            squarechoice1ofpc = 1
        }
        
        if  image2.image == UIImage(named: "black square.png")  {
            squarechoice2ofpc = 5
        } else if image2.image == UIImage(named: "grey square.png") {
            squarechoice2ofpc = 4
        } else if image2.image == UIImage(named: "red square.png"){
            squarechoice2ofpc = 3
        } else if image2.image == UIImage(named: "green square.png"){
            squarechoice2ofpc = 2
        } else if image2.image == UIImage(named: "dark blue square.png") {
            squarechoice2ofpc = 1
        }
        imagesonscreen = (squarechoice1ofpc,squarechoice2ofpc)
       

    }
    
    
    
    func rpsonscreencheck () {

        if image1.image == UIImage(named: "rock.png")  {
            rpschoice1ofpc = 3
        } else if image1.image == UIImage(named: "paper.png") {
            rpschoice1ofpc = 2
        }  else if image1.image == UIImage(named: "scissors.png") {
            rpschoice1ofpc = 1
        }
       
        
        if image2.image == UIImage(named: "rock.png")  {
            rpschoice2ofpc = 3
        } else if image2.image == UIImage(named: "paper.png") {
            rpschoice2ofpc = 2
        } else if image2.image == UIImage(named: "scissors.png") {
            rpschoice2ofpc = 1
        }
        
        imagesonscreen = (rpschoice1ofpc, rpschoice2ofpc)
       
    }
    
    
    
    func onscreencheck () {
        if decisionchoice.text == "rpsimages" {
        rpsonscreencheck()
        
    } else if decisionchoice.text == "squareimages"{
        squareonscreencheck()                       }
    }
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  
    
    
    
    
    
    
    
    
    
    func imageone () {
        if decisionchoice.text == "rpsimages" {
        
 
        if image1.image == UIImage(named: "rock.png")  {
            winnerchoice = 3
        } else if image1.image == UIImage(named: "paper.png") {
            winnerchoice = 2
        } else {
            winnerchoice = 1
            }
        
        
        
        } else {
        
            if image1.image == UIImage(named: "black square.png")  {
                winnerchoice = 5
            } else if image1.image == UIImage(named: "grey square.png") {
                winnerchoice = 4
            } else if image1.image == UIImage(named: "red square.png"){
                winnerchoice = 3
            } else if image1.image == UIImage(named: "green square.png"){
                winnerchoice = 2
            } else if image1.image == UIImage(named: "dark blue square.png") {
                winnerchoice = 1
            }
        }
        
     
    }
    
    
    
    
    
    
    func imagetwo () {
        if decisionchoice.text == "rpsimages" {
            
            
        if image2.image == UIImage(named: "rock.png")  {
            winnerchoice = 3
            
        } else if image2.image == UIImage(named: "paper.png") {
            winnerchoice = 2
            
        }  else if image2.image == UIImage(named: "scissors.png") {
            winnerchoice = 1
        }
        
            
            
        } else if decisionchoice.text == "squareimages" {
            
            if image2.image == UIImage(named: "black square.png")  {
                winnerchoice = 5
                
            } else if image2.image == UIImage(named: "grey square.png") {
                winnerchoice = 4
                
            } else if image2.image == UIImage(named: "red square.png"){
                winnerchoice = 3
                
            } else if image2.image == UIImage(named: "green square.png"){
                winnerchoice = 2
                
            } else if image2.image == UIImage(named: "dark blue square.png") {
                winnerchoice = 1
            }
            
        }
     
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

     override func viewDidLoad() {
        points = 0
        let defaults = NSUserDefaults.standardUserDefaults()
        if defaults.objectForKey("DecisionScores") != nil {
        decisionArr = defaults.objectForKey("DecisionScores") as? [String] ?? [String]()
        }
        if defaults.stringForKey("DateCheck2") != nil {
            simpleDate = defaults.stringForKey("DateCheck2") as String!
        }
        
        formatter.dateStyle = .MediumStyle
        
        dateCheck = formatter.stringFromDate(now)
        
        
        
        super.viewDidLoad()
        choiceofarray()
        // Do any additional setup after loading the view, typically from a nib.
    }

     override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


