//
//  InitialView.swift
//  MultipleStoryboards
//
//  Created by Nakul Malhotra on 1/21/16.
//  Copyright © 2016 myOrg. All rights reserved.
//

import Foundation
import UIKit
import ParseUI
import Parse



let user1 = PFObject(className: "Users")
var name = ""
var email = ""
let user = PFUser()
let today = PFObject(className: name)
var homeroom = ""
var grade = ""
let homeRoomScores = PFObject(className: homeroom)
let gradeScores = PFObject(className: grade)






















class InitialView: UIViewController {

    @IBAction func StartButton(sender: AnyObject) {
        
        today.saveEventually()
        
     let defaults = NSUserDefaults.standardUserDefaults()
        
        if defaults.stringForKey("Name") != nil {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewControllerWithIdentifier("WelcomeView") as UIViewController
            self.presentViewController(controller, animated: true, completion: nil)
            
            

        } else {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewControllerWithIdentifier("LoginScreen") as UIViewController
            self.presentViewController(controller, animated: true, completion: nil)
        }

    }

}




















func viewDidLoad() {





}



