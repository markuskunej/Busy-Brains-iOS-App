//
//  ViewController.swift
//  Colour Memory
//
//  Created by Noah Kunej on 2015-11-15.
//  Copyright © 2015 Markus Kunej. All rights reserved.
//

import UIKit
import Parse
import Bolts

var colourMemoryScore = String()






class ViewController: UIViewController, UIAlertViewDelegate {
    enum ButtonColor: Int {
        case Red = 1
        case Green = 2
        case Blue = 3
        case Yellow = 4
    }
    
    func countdown() {
        seconds = 3
        
        launchTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: Selector("updateCountdownTimer"), userInfo: nil, repeats: true)    }
    
    
    
    
    enum WhoseTurn {
        case Human
        case Computer
    }
    
    @IBOutlet weak var redButton: UIButton!
    @IBOutlet weak var greenButton: UIButton!
    @IBOutlet weak var blueButton: UIButton!
    @IBOutlet weak var yellowButton: UIButton!
    
    @IBOutlet weak var roundText: UILabel!
    
    var launchTimer = NSTimer()
    
    
    
    let winningNumber: Int = 25
    
    var currentPlayer: WhoseTurn = .Computer
    
    var inputs = [ButtonColor]()
    
    var indexOfNextButtonToTouch: Int = 0
    
    var highlightSquareTime = 0.5
    
    var round = 0
    
    var now = NSDate()
    
    let formatter = NSDateFormatter()
    
    var dateCheck = String()
    
    var simpleDate = String()
    
    var simonArr = [String]()
    
    var seconds = 3

    @IBOutlet weak var launchtimerLabel: UILabel!

    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let defaults = NSUserDefaults.standardUserDefaults()
        if defaults.objectForKey("MemoryScores") != nil {
            simonArr = defaults.objectForKey("MemoryScores") as? [String] ?? [String]()
        }
        if defaults.stringForKey("DateCheck4") != nil {
            simpleDate = defaults.stringForKey("DateCheck4") as String!
        }
        
        formatter.dateStyle = .MediumStyle
        
        dateCheck = formatter.stringFromDate(now)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(animated: Bool) {
        
        countdown()
    }
    
    
    
    func buttonByColor(color: ButtonColor) -> UIButton {
        switch color {
        case .Red:
            return redButton
        case .Green:
            return greenButton
        case .Blue:
            return blueButton
        case .Yellow:
            return yellowButton
        }
    }
    
    
    func playSequence(index: Int, highlightTime: Double) {
        currentPlayer = .Computer
        
        
        
        if index == inputs.count {
            currentPlayer = .Human
            
            return
        }
        
        let button: UIButton = buttonByColor(inputs[index])
        let originalColor: UIColor? = button.backgroundColor
        let highlightColor: UIColor = UIColor.whiteColor()
        
        UIView.animateWithDuration(highlightTime,
            delay: 0.0,
    options:UIViewAnimationOptions.CurveLinear.intersect(.AllowUserInteraction).intersect(.BeginFromCurrentState),
            animations: {
                button.backgroundColor = highlightColor
            }, completion: { finished in
                button.backgroundColor = originalColor
                let newIndex: Int = index + 1
                self.playSequence(newIndex, highlightTime: highlightTime)
                
            })
        }
    
    
    
    
    @IBAction func buttonTouched(sender: UIButton) {
        
        let buttonTag: Int = sender.tag
        
        if let colorTouched = ButtonColor(rawValue: buttonTag) {
            if currentPlayer == .Computer {
                return
            }
            
            if colorTouched == inputs[indexOfNextButtonToTouch] {
                indexOfNextButtonToTouch++
                
                if indexOfNextButtonToTouch == inputs.count {
                    if advanceGame() == false {
                        playerWins()
                    }
                    indexOfNextButtonToTouch = 0
                }
                else {
                    
                }
            }
            else {
                playerLoses()
                indexOfNextButtonToTouch = 0
                
            }
        }
    }
    
    func saveScore() {
        formatter.dateStyle = .MediumStyle
        
        simpleDate = formatter.stringFromDate(now)
        
        colourMemoryScore = "\(simpleDate): \(round)"
        
        simonArr.append(colourMemoryScore)
        
        let defaults = NSUserDefaults.standardUserDefaults()
        
        defaults.setObject(simonArr, forKey: "MemoryScores")
        
        defaults.setObject(simpleDate, forKey: "DateCheck4")
        name = String(name)
        
        
        homeRoomScores.setValue(round, forKey: "SimonScore")
        gradeScores.setValue(round, forKey: "SimonScore")
        today.setValue(round, forKey: "SimonScore")
        user1.setValue(round, forKey: "SimonScore")
        user.setValue(round, forKey: "SimonScore")
        
        
        user.saveEventually()
        user1.saveEventually()
        today.saveEventually()
        homeRoomScores.saveEventually()
        gradeScores.saveEventually()
        
        
        
    }
    
    func playerWins() {
        let winner: UIAlertView = UIAlertView(title: "You Won!", message: "Congratulations!", delegate: self, cancelButtonTitle: nil, otherButtonTitles: "Awesome!")
        winner.show()
    }
    
    func playerLoses() {
        let loser: UIAlertView = UIAlertView(title: "Good Job!", message: "You made it to round \(round)!", delegate: self, cancelButtonTitle: nil, otherButtonTitles: "Back")
        loser.show()
            let controller = storyboard!.instantiateViewControllerWithIdentifier("ColourMain") as UIViewController
        saveScore()
            
            self.presentViewController(controller, animated: true, completion: nil)    }
    
    func randomButton() -> ButtonColor {
        let v: Int = Int(arc4random_uniform(UInt32(4))) + 1
        let result = ButtonColor(rawValue: v)
        return result!
    }
    
    func startNewGame() -> Void {
        inputs = [ButtonColor]()
        advanceGame()
    }
    
    func advanceGame() -> Bool {
        var result: Bool = true
        round = round + 1
        roundText.text = "Round \(round)"
        
        if inputs.count == winningNumber {
            result = false
        }
        else {
            inputs += [randomButton()]
            
            playSequence(0, highlightTime: highlightSquareTime)
        }
        
        return result
    }
    
    func updateCountdownTimer() {
        if (seconds == 1) {
            launchTimer.invalidate()
            launchtimerLabel.hidden = true
            startNewGame()
        } else {
            seconds--
            launchtimerLabel.text = "\(seconds)"
        }
        
    }
        
}
