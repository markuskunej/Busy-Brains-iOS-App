//
//  ViewController3.swift
//  Colour Memory
//
//  Created by Noah Kunej on 2015-12-15.
//  Copyright © 2015 Markus Kunej. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    
    var dateCheck = String()
    
    let formatter = NSDateFormatter()
    
    var simpleDate = String()
    
    var now = NSDate()
    
    @IBAction func BackToHome(sender: AnyObject) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("WelcomeView") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)
        
    }
    @IBOutlet weak var rules: UILabel!
    
    @IBAction func start(sender: AnyObject) {
        if pass == true  {
            let controller = storyboard!.instantiateViewControllerWithIdentifier("MemoryGame") as UIViewController
            
            self.presentViewController(controller, animated: true, completion: nil)
        
        } else {
        if simpleDate != dateCheck{

            let controller = storyboard!.instantiateViewControllerWithIdentifier("MemoryGame") as UIViewController
            
            self.presentViewController(controller, animated: true, completion: nil)        }
        
        else {
            rules.text = "Sorry, you can only play once per day!"
            }  }  }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = NSUserDefaults.standardUserDefaults()
        if defaults.stringForKey("DateCheck4") != nil {
            simpleDate = defaults.stringForKey("DateCheck4") as String!
        }
        
        formatter.dateStyle = .MediumStyle
        
        dateCheck = formatter.stringFromDate(now)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
