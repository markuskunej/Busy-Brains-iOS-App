//
//  reactiontimeScores.swift
//  MultipleStoryboards
//
//  Created by Noah Kunej on 2016-01-03.
//  Copyright © 2016 myOrg. All rights reserved.
//

import UIKit

class reactiontimeScores: UIViewController, UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return timeArr.count
    }
    
    
 

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        
        
        let(scores) = timeArr [indexPath.row]
        
        cell.backgroundColor = UIColor.clearColor();
        
        cell.textLabel!.textColor = UIColor.whiteColor();
        
        
        cell.textLabel!.text = scores
        return cell
    }
    
    var timeArr = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = NSUserDefaults.standardUserDefaults()
        timeArr = defaults.objectForKey("TimeScores") as? [String] ?? [String]()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
