

import UIKit
import AVFoundation
import Parse
var rememoryMemoryScore: Int = 0

class GameViewController: UIViewController {
    
    
    @IBOutlet weak var greenButton: GameButton!
    @IBOutlet weak var blueButton: GameButton!
    @IBOutlet weak var yellowButton:GameButton!
    @IBOutlet weak var redButton: GameButton!
    @IBOutlet weak var youLoseX: UILabel!
    @IBOutlet weak var scorebutton: UIButton!
    
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var Playneeded: UIButton!
    var interactionEnabled = false
    var game = Game.init()
    var buttons: NSDictionary!
    var currentStepBox: Int = 0
    var timer: NSTimer!
    var playerTimer: NSTimer!
    var boxToStop: GameButton!
    var playerStep: Int = 0
    var buzzer: TonePlayer!
    var computerTurnActive: Bool = false
    var awaitingPlayGame: Bool = true
    
    var now = NSDate()
    
    let formatter = NSDateFormatter()
    
    var dateCheck = String()
    
    var simpleDate = String()
    
    var data = String()
    
    var simon2Arr = [String]()
    
    
    
    @IBAction func BackToHome(sender: AnyObject) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewControllerWithIdentifier("WelcomeView") as UIViewController
            
            self.presentViewController(controller, animated: true, completion: nil)
    }
    
    
    override func loadView() {
        view = UIView(frame: UIScreen.mainScreen().bounds)
        let bundle = NSBundle.mainBundle()
        bundle.loadNibNamed("GameViewController", owner: self, options: nil)
    }
    
    func initializeGameView() {
        
        // Re-initialize the Game class
        game = Game.init()
        
        // Set up variables for the next play
        currentStepBox = 0
        playerStep = 0
        playButton.userInteractionEnabled = true
        playButton.hidden = true
        scorebutton.hidden = false
        awaitingPlayGame = true
    }
    func willResign() {
        // Get game ready to enter background
        playButton.setTitle("Play Game", forState: UIControlState.Normal)
        interactionEnabled = false
        redButton.off()
        greenButton.off()
        blueButton.off()
        yellowButton.off()
        youLoseX.hidden = true
        updateScore()
    }
    
    func enteredBackground() {
        // get ready to restart
        playButton.hidden = false
        initializeGameView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set up the audio players for the game
        let defaults = NSUserDefaults.standardUserDefaults()
        if defaults.objectForKey("Simon2Scores") != nil {
            simon2Arr = defaults.objectForKey("Simon2Scores") as? [String] ?? [String]()
        }
        if defaults.stringForKey("DateCheck5") != nil {
            simpleDate = defaults.stringForKey("DateCheck5")as String!
        }
        
        
        formatter.dateStyle = .MediumStyle
        
        dateCheck = formatter.stringFromDate(now)
        greenButton.createPlayer("greenLowE.caf")
        redButton.createPlayer("redA.caf")
        blueButton.createPlayer("blueHiE.caf")
        yellowButton.createPlayer("yellowC#.caf")
        let thePath: String = NSBundle.mainBundle().resourcePath!
        let theURL: NSURL = NSURL(fileURLWithPath: thePath).URLByAppendingPathComponent("youLoseBuzzer.caf")
        do {
            buzzer = try TonePlayer(contentsOfURL: theURL)
        } catch let error1 as NSError {
            let error = error1
            print(error)
            buzzer = nil
        }
        
        do {
            // Set audio to play even if mute switch is on since it's important to the game play
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
        } catch _ {
            
        }
        
        
        // Set up the big red "X"
        youLoseX.textColor = UIColor.redColor()
        youLoseX.hidden = true
        
        
        // Create a dictionary to associate theSequence array values to the button objects
        buttons = [0 : greenButton, 1 : redButton, 2 : yellowButton, 3 : blueButton]
        
        NSNotificationCenter.defaultCenter().addObserver(self,
            selector: "willResign",
            name: "willResignActive",
            object: nil)
        
        NSNotificationCenter.defaultCenter().addObserver(self,
            selector: "enteredBackground",
            name: "didEnterBackground",
            object: nil)
    }
    
    @IBAction func playGame(sender: UIButton) {
        // Make game buttons unresponsive, hide the Play button and start the computer turn
        if pass == true {
        
        
        
        } else {
        
        if simpleDate != dateCheck {
        scorebutton.hidden = true
            backButton.hidden = true
        playButton.userInteractionEnabled = false
        updateScore()
        playButton.hidden = true
        playButton.setTitle("Play Again", forState: UIControlState.Normal)
        youLoseX.hidden = true
        computerTurn()
            } }
    }
    
    
    @IBOutlet var backButton: UIButton!
    @IBAction func Scores(sender: UIButton) {
        let storyboard = UIStoryboard(name: "BrainMainScores", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("BrainScores") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)
    
    }
    
    
    func computerTurn() {
        // Starts a timer which calls function to play each button in the sequence until invalidated by playing one more
        // step than the last successful turn
        interactionEnabled = false
        computerTurnActive = true
        timer = NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: "playButtonController", userInfo: nil, repeats: true)
    }
    
    func playButtonController() {
        // Controls the playing of the buttons
        if currentStepBox > 0 {
            boxToStop.off()
        }
        if currentStepBox == (game.score + 1) {
            // if all the steps are played in the current sequence
            timer.invalidate()
            interactionEnabled = true
            computerTurnActive = false
            awaitingPlayGame = false
            playerStep = 0
            return
        }
        playerTimer = NSTimer.scheduledTimerWithTimeInterval(0.2, target: self, selector: "playTheButton", userInfo: nil, repeats: false)
        
    }
    
    func playTheButton() {
        // Plays the button
        let whichButton = game.theSequence[currentStepBox]
        let thePlayButton = buttons[whichButton] as! GameButton
        boxToStop = thePlayButton
        thePlayButton.on()
        currentStepBox++
    }
    
    func updateScore() {
        scoreLabel.text = "Score: \(game.score)"
        rememoryMemoryScore++
    }
    
    @IBAction func buttonPressed(sender: GameButton) {
        // hitting a button disables other buttons so you can't activate more than one at a time
        if interactionEnabled {
            interactionEnabled = false
            sender.on()
            let x: Int = buttons.allKeysForObject(sender)[0] as! Int
//            let sequenceStep = game.theSequence[playerStep]
            
            // Check to see if the button value matches the step in the sequence and update the sore
            if x == game.theSequence[playerStep] {
                playerStep++
                
                // Check to see if that's the last step in the current sequence and if so, increment the score
                if playerStep == game.score + 1 {
                    game.score++
                    updateScore()
                    currentStepBox = 0
                    interactionEnabled = false
                    computerTurn()
                }
            } else {
                youLose()
                        }
            
        }
    }
    
    @IBAction func buttonResigned(sender: GameButton) {
        // lifting finger off button turns the button off and re-enables interaction as long as it's not disabled for another reason
        sender.off()
        if !computerTurnActive && !awaitingPlayGame {
            interactionEnabled = true
        }
    }
    
    func youLose() {
        // If you hit the wrong button, you get the big buzzer, the big red x and game is reinitialized to start again
        buzzer.play()
        youLoseX.hidden = false
        awaitingPlayGame = true
        saveScores()
        initializeGameView()
    }
    func saveScores() {
        backButton.hidden = false
        
        formatter.dateStyle = .MediumStyle
        
        simpleDate = formatter.stringFromDate(now)
        
        rememoryMemoryScore = rememoryMemoryScore - 1
        
        data = "\(simpleDate): \(rememoryMemoryScore)"
        
        simon2Arr.append(data)
        
        let defaults = NSUserDefaults.standardUserDefaults()
        
        defaults.setObject(simon2Arr, forKey: "Simon2Scores")
        
        defaults.setObject(simpleDate, forKey: "DateCheck5")
        
        
        
        homeRoomScores.setValue(rememoryMemoryScore, forKey: "AudioSimonScore")
        gradeScores.setValue(rememoryMemoryScore, forKey: "AudioSimonScore")
        today.setValue(rememoryMemoryScore, forKey: "AudioSimonScore")
        user1.setValue(rememoryMemoryScore, forKey: "AudioSimonScore")
        user.setValue(rememoryMemoryScore, forKey: "AudioSimonScore")
        
        
        user1.saveEventually()
        user.saveEventually()
        today.saveEventually()
        homeRoomScores.saveEventually()
        gradeScores.saveEventually()
        
        
    }
    
    
    
}
