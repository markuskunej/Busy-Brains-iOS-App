

import UIKit

class Game {
    
    var playerStepNumber: Int
    var totalSteps: Int
    var score: Int
    var theSequence: [Int] = [0]
    
    
    
    init() {
        playerStepNumber = 0
        totalSteps = 0
        score = 0
        // Set a sequence of 1000 steps - can anyone do that much?
        theSequence.removeAll(keepCapacity: true)
        for _ in 1...1000 {
            let aStep: Int =  Int(arc4random_uniform(UInt32(4)))
            theSequence.append(aStep)
        }
    }
    
    
    
    func checkPlayerStep (stepNumber stepNumber: Int, playerStep: Int) -> Bool {
        // check if button selected matches sequence
        if playerStep == theSequence[stepNumber] {
            score++
            return true
        } else {return false}
    }
    
}
