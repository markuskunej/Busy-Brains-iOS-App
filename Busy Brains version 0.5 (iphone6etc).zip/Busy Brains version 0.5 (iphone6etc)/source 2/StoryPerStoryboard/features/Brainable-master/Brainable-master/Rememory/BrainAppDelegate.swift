

import UIKit



class BrainAppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: UIStatusBarAnimation.None)
        window = UIWindow(frame: UIScreen.mainScreen().bounds)
        let gvc = GameViewController()
        window!.rootViewController = gvc
        window!.backgroundColor = UIColor.whiteColor()
        window!.makeKeyAndVisible()
        
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
               NSNotificationCenter.defaultCenter().postNotificationName("willResignActive", object: nil)
    }
    func applicationDidEnterBackground(application: UIApplication) {

    }
    func applicationWillEnterForeground(application: UIApplication) {
               NSNotificationCenter.defaultCenter().postNotificationName("didEnterBackground", object: nil)
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

