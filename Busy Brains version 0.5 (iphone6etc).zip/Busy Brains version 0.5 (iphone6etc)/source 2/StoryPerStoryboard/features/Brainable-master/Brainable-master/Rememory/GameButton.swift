
import UIKit

class GameButton: UIButton {
    
    var player: TonePlayer?
    
    // Give the button a tone
    
    func createPlayer(filename: String) {
        var error: NSError?
        let thePath: String = NSBundle.mainBundle().resourcePath!
        let theURL: NSURL = NSURL(fileURLWithPath: thePath).URLByAppendingPathComponent(filename)
        do {
            player = try TonePlayer(contentsOfURL: theURL)
        } catch let error1 as NSError {
            error = error1
            print(error1)
            player = nil
        }
        if let actualError = error {
            print("An Error Occurred: \(actualError) the URL was: \(theURL)")
        }
        player?.prepareToPlay()
    }
    
    func on() {
        // light up button and play sound
        self.alpha = 1.0
        player?.play()
    }
    
    func off() {
        // turn off button and stop sound
        self.alpha = 0.5
        player?.stop()
    } 
}
