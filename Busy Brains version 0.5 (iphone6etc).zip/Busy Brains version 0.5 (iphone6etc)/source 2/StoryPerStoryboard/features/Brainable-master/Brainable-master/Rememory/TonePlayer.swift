

import UIKit
import AVFoundation

class TonePlayer: AVAudioPlayer {
    
    let playDelay: NSTimeInterval = 0.03
    let muteDelay: NSTimeInterval = 0.03
    
    
    // delay before unmuting and muting is to avoid clicks in output
    // these delays are the sole reason for subclassing AVAudioPlayer
    
    override func play() -> Bool {
        if super.play() {
            _ = NSTimer.scheduledTimerWithTimeInterval(playDelay, target: self, selector: "unMute", userInfo: nil, repeats: false)
            return true
        } else {return false}
    }
    // Delay after muting before stopping to avoid click
    override func stop() {
        self.mute()
        _ = NSTimer.scheduledTimerWithTimeInterval(muteDelay, target: self, selector: "stopSuper", userInfo: nil, repeats: false)
        self.prepareToPlay()
    }
    
    
//    Couldn't make 'super' the argument for target in the stop timer call (why?), so calling it here
    
    func stopSuper() {
    super.stop()
    }
    
    func mute() {
        self.volume = 0
        
    }
    
    func unMute() {
        self.volume = 1
    }
    
}
//    var thePath: NSString


//    init(audioFileName: NSString) {
//        var theBundle: NSString = NSBundle.mainBundle().resourcePath!
//        thePath.stringByAppendingPathComponent(audioFileName as String)
//        var theURL: NSURL = NSURL(fileURLWithPath: thePath as String)!
//        super.init(contentsOfURL: theURL, error: nil)
//    }