//
//  BrainMainScores.swift
//  MultipleStoryboards
//
//  Created by Nakul Malhotra on 12/16/15.
//  Copyright © 2015 myOrg. All rights reserved.
//

import Foundation


import UIKit



class BrainMainScores: UIViewController, UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return simon2Arr.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        
        
        let(scores) = simon2Arr [indexPath.row]
        
        cell.backgroundColor = UIColor.clearColor();
        
        cell.textLabel!.textColor = UIColor.whiteColor();
        
        
        cell.textLabel!.text = scores
        return cell
    }
    
    var simon2Arr = [String]()
    
    @IBAction func back(sender: AnyObject) {
        
        //var window: UIWindow?
        
        
        // Override point for customization after application launch.
        //UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: UIStatusBarAnimation.None)
        //window = UIWindow(frame: UIScreen.mainScreen().bounds)
        let gvc = GameViewController()
        //window!.rootViewController = gvc
        //window!.backgroundColor = UIColor.whiteColor()
        //window!.makeKeyAndVisible()
        
        self.presentViewController(gvc, animated: true, completion: nil)
    }
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let defaults = NSUserDefaults.standardUserDefaults()
        
        simon2Arr = defaults.objectForKey("Simon2Scores") as? [String] ?? [String]()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  
    
    
    
    
    
    
    
    
    
}
