//
//  WelcomeViewController.swift
//  StoryPerStoryboard
//
//  Created by Milan Nankov on 10/7/14.
//  Copyright (c) 2014 myOrg. All rights reserved.
//

import UIKit
import Parse
import ParseUI

let UsersObjectId = user1.objectId!


let HomeroomObjectId = homeRoomScores.objectId!


let GradeObjectId = gradeScores.objectId!


let IndividualObjectId = today.objectId!


class WelcomeViewController: UIViewController {
    
    
  
    
    
    @IBOutlet weak var nameBox: UILabel!
    
    var username = String()
    
    
    
    
    
    override func viewDidLoad() {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            let defaults = NSUserDefaults.standardUserDefaults()
            
            homeroom = defaults.stringForKey("Homeroom")!
            
            grade = defaults.stringForKey("Grade") as String!
            
            name = defaults.stringForKey("Name") as String!
            
            email = defaults.stringForKey("Email") as String!
            
            
            username = defaults.stringForKey("Name")!
            
            nameBox.text = "Welcome Back, \(username)!"
            
            
            
            username = defaults.stringForKey("Name")!
            
            nameBox.text = "Welcome Back, \(username)!"
        
        
            PFUser.logInWithUsernameInBackground(name, password: "my pass")
        
            today.saveEventually()
        
        
        
        
        
        
        
            
            
            homeRoomScores["name"] = name
            gradeScores["name"] = name
            user1["name"] = name
        

            user1.saveEventually()
            user.saveEventually()
            homeRoomScores.saveEventually()
            gradeScores.saveEventually()
            today.saveEventually()
                


        // Do any additional setup after loading the view.
    
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onSimonSaysPressed(sender: AnyObject) {
        let storyboard = UIStoryboard(name: "ColourMain", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("ColourMain") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)

        
    }

    @IBAction func onDecisonPressed(sender: UIButton)
    {
        let storyboard = UIStoryboard(name: "Decision", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("InitialController") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)
    }

    @IBAction func onMathControllerPressed(sender: UIButton)
    {
        let storyboard = UIStoryboard(name: "Math", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("MathController") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)
    }
    
    @IBAction func onMemoryPressed(sender: UIButton)
    {
        let storyboard = UIStoryboard(name: "memory", bundle: nil)
        let controller = storyboard.instantiateViewControllerWithIdentifier("MemoryController") as UIViewController
        
        self.presentViewController(controller, animated: true, completion: nil)
    }
    
    
    @IBAction func onSimonPressed(sender: UIButton)
    {
         //var window: UIWindow?

     
            // Override point for customization after application launch.
            //UIApplication.sharedApplication().setStatusBarHidden(true, withAnimation: UIStatusBarAnimation.None)
            //window = UIWindow(frame: UIScreen.mainScreen().bounds)
            let gvc = GameViewController()
            //window!.rootViewController = gvc
            //window!.backgroundColor = UIColor.whiteColor()
            //window!.makeKeyAndVisible()
        
        self.presentViewController(gvc, animated: true, completion: nil)
        
        
        
        
    
    }
    
    
    
    
    
    
    
    
    
    
    
}
